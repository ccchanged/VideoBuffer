package com.example.instantreplay.recording

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.instantreplay.bridge.NativeBridge
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Exports the current buffer snapshot to an MP4 file using MediaMuxer.
 *
 * Reads frames from the Rust export snapshot and muxes them into a file saved
 * to the device's Movies directory.
 */
object ReplayExporter {
    private const val TAG = "ReplayExporter"
    private const val MIME_TYPE = MediaFormat.MIMETYPE_VIDEO_AVC

    /**
     * Export the replay buffer to an MP4 file.
     *
     * This should be called on a background thread. It blocks until the export
     * is complete.
     *
     * @param context Application context for accessing MediaStore.
     * @param durationSec How many seconds of replay to export.
     * @param width Video width.
     * @param height Video height.
     * @return The file path of the exported MP4, or null on failure.
     */
    fun export(
        context: Context,
        durationSec: Int,
        width: Int,
        height: Int,
    ): String? {
        val frameCount = NativeBridge.nativeBeginExport(durationSec)
        if (frameCount <= 0) {
            Log.w(TAG, "No frames to export")
            return null
        }

        Log.i(TAG, "Exporting $frameCount frames")

        // Create a temporary file first, then copy to MediaStore on success.
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "Replay_$timestamp.mp4"
        val tempFile = File(context.cacheDir, fileName)

        var muxer: MediaMuxer? = null
        var videoTrack = -1
        var success = false

        try {
            muxer = MediaMuxer(tempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // Set up the video track with codec config (SPS/PPS).
            val codecConfig = NativeBridge.nativeGetExportCodecConfig()
            val format = MediaFormat.createVideoFormat(MIME_TYPE, width, height)
            if (codecConfig != null) {
                format.setByteBuffer("csd-0", ByteBuffer.wrap(codecConfig))
            }
            videoTrack = muxer.addTrack(format)
            muxer.start()

            // Write each frame.
            val outInfo = LongArray(2) // [presentationTimeUs, flags]
            val bufferInfo = MediaCodec.BufferInfo()

            for (i in 0 until frameCount) {
                val data = NativeBridge.nativeGetExportFrame(i, outInfo)
                if (data == null) {
                    Log.w(TAG, "Null frame at index $i, stopping export")
                    break
                }

                bufferInfo.apply {
                    offset = 0
                    size = data.size
                    presentationTimeUs = outInfo[0]
                    flags = outInfo[1].toInt()
                    // Don't pass codec config flag to muxer — it's already in the format.
                    if (flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        return@apply
                    }
                }

                // Skip codec config frames (already set up in format).
                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                    continue
                }

                muxer.writeSampleData(videoTrack, ByteBuffer.wrap(data), bufferInfo)
            }

            success = true
            Log.i(TAG, "Export complete: $fileName")
        } catch (e: Exception) {
            Log.e(TAG, "Export failed", e)
        } finally {
            try {
                muxer?.stop()
                muxer?.release()
            } catch (e: Exception) {
                Log.w(TAG, "Error finalizing muxer", e)
                success = false
            }
            NativeBridge.nativeEndExport()
        }

        if (!success) {
            tempFile.delete()
            return null
        }

        // Move to MediaStore (Movies directory).
        return saveToMediaStore(context, tempFile, fileName)
    }

    private fun saveToMediaStore(context: Context, tempFile: File, fileName: String): String? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/InstantReplay")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)

        if (uri == null) {
            Log.e(TAG, "Failed to create MediaStore entry")
            tempFile.delete()
            return null
        }

        try {
            resolver.openOutputStream(uri)?.use { output ->
                tempFile.inputStream().use { input ->
                    input.copyTo(output)
                }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write to MediaStore", e)
            resolver.delete(uri, null, null)
            tempFile.delete()
            return null
        }

        tempFile.delete()
        val path = "${Environment.DIRECTORY_MOVIES}/InstantReplay/$fileName"
        Log.i(TAG, "Saved to: $path")
        return path
    }
}
